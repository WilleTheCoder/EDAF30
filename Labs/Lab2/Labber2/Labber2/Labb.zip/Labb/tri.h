

#include <string>
#include <vector>

using namespace std;


	vector<string> getTrigrams(string word);

	int nbrOfTrigrams(string word);

	void proc(string word, ofstream& out);



