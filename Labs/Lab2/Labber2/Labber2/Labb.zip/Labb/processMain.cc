#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <fstream>
#include "tri.h"

using namespace std;
/*
int main() {
	ifstream in("dict.txt");
	ofstream out("words.txt");
	string word;
	while (getline(in, word)) {
		transform(word.begin(), word.end(), word.begin(), tolower);
		proc(word, out);
	}
	return 0;
}
*/