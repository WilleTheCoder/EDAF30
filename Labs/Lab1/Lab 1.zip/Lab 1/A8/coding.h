#ifndef __CODING_H
#define __CODING_H

unsigned char encode(unsigned char c);
unsigned char decode(unsigned char c);
#endif
