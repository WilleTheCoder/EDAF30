#include <iostream>

using std::cout;
int main(){
cout << "hello world";
return 0;
}
