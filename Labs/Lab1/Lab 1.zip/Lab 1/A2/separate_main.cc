#include "separate_fn.h"

int main()
{
    the_function("Called from main()");
    exit(0);
}
