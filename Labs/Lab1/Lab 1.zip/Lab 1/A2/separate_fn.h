#include <string>
void the_function(const std::string& s);

