#include <iostream>

void the_function(const std::string& s)
{
    std::cout << "the_function: " << s << "\n";
}
