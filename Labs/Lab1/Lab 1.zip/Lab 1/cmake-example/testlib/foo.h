void foo_fun();
